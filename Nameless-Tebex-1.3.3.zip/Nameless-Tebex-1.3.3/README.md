# Nameless-Tebex
Integrate your Nameless website with your Tebex store.

## Requirements
- NamelessMC version 2.1.0+
- [Tebex](https://www.tebex.io/)

## Installation
1. Upload the contents of the **upload** directory straight into your NamelessMC installation's directory
2. Activate the module in the StaffCP -> Modules tab
3. Configure the module in the StaffCP -> Tebex -> Tebex tab
4. Run an initial synchronisation in the StaffCP -> Tebex -> Force Sync tab