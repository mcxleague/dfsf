# Made by Coldfire - https://coldfiredzn.com

# Rules Module for NamelessMC - Docs

# Installation:
- Note: Make sure you have NamelessMC version v2 pre-13! NamelessMC v1 will NOT work!
- Unzip the file and upload the contents of the "upload" file straight into your main NamelessMC installation directory (where the folders custom, core, modules, uploads, cache are)
- Head over to StaffCP -> Modules, click the "install" button
- Enable the "Rules" module
- You're done! Configure the Rules Module at StaffCP -> Rules.

# Support Discord: 
- [Coldfire Design](https://coldfiredzn.com/discord)
