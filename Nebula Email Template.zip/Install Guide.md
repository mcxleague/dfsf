Hello, thank you for downloading my resource.

Steps to install this:
1. Goto /custom/templates/
2. Click on your template. Once you open your template file, look for a folder named email.
3. Open that and replace the files.

If you have any issues with the Email template, you can join my Discord server.

Discord link: https://discord.com/invite/7AYYyjZ4B8